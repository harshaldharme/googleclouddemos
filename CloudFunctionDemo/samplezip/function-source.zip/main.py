# using SendGrid's Python Library
# https://github.com/sendgrid/sendgrid-python
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

sg = SendGridAPIClient('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')

def send_mail(data, context):
    message = Mail(
        from_email='edurekagcpbatch18062022@gmail.com',
        to_emails='hvdharme@gmail.com',
        subject='LearnWithHarshal - Send Email from Cloud Function Demo',
        html_content="Hello <strong>Harshal</strong>, <br/>The file which was uploaded to <strong>{}</strong> is <strong>{}</strong>.<br/>Thank You..!".format(data['bucket'], data['name'])
    )
    response = sg.send(message)
